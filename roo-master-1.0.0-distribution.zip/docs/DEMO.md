# Roo Master System Demonstration Guide

This guide provides instructions for setting up and running a demonstration of the Roo Master system's capabilities.

## Prerequisites

Before running the demonstration, ensure you have the following prerequisites installed and configured on your system:

- **Git**: Version control system. Ensure it's installed and accessible from your PowerShell terminal.
- **Node.js**: JavaScript runtime (LTS version recommended). Includes npm for package management.
- **TypeScript**: A superset of JavaScript that compiles to plain JavaScript.
- **PowerShell**: For running the demonstration scripts.
- **Docker**: (Optional) If you plan to run the MCP host in a container.

## 0. Initialize Git Repository

The demo requires a properly initialized Git repository. If you are running this demo in a fresh environment or have not yet initialized a Git repository for this project, please run the following script first:

```powershell
./scripts/init-demo.ps1
```

This script will:
- Initialize a new Git repository (`git init`).
- Add all current project files to the repository (`git add .`).
- Create an initial commit (`git commit -m "Initial commit of project files for demo setup"`).

This ensures that the `git worktree` commands in `run-demo.ps1` function correctly.

## 1. Directory Structure

The Roo Master project has a specific directory structure that is important to understand for the demonstration:

-   **`roo-master/` (Root Directory)**: This is the main repository where the demo scripts are executed.
    -   **`scripts/`**: Contains PowerShell scripts for initializing, running, and cleaning up the demo.
        -   `init-demo.ps1`: Initializes the Git repository.
        -   `run-demo.ps1`: Automates the demonstration steps, including worktree creation, project copying, and npm command execution.
        -   `clean-demo.ps1`: Cleans up the demo environment (worktree and branch).
    -   **`roo-demo-project/`**: This is a sample Node.js/TypeScript project that is used within the demo. It contains `package.json`, `src`, `test`, `tsconfig.json`, and `.eslintrc.js`.
    -   **`docs/`**: Contains documentation, including this guide.
    -   **`packages/`**: Contains the source code for the Roo Master system components (e.g., `mcp-host`, `vscode-ext`).

-   **`roo-demo-worktree/` (Git Worktree)**: This directory is created by `run-demo.ps1` during the demonstration. It acts as an isolated development environment for the `feature/demo-branch`.
    -   **`roo-demo-worktree/roo-demo-project/`**: Inside the worktree, a copy of the `roo-demo-project` is placed here. All `npm` commands in the demo are executed from this nested location within the worktree.

Understanding this structure is crucial for following the demo's execution flow and troubleshooting any path-related issues.

## 2. Environment Setup

## 3. Cleaning Up Previous Demo Runs

To ensure a clean slate for each demonstration run and avoid conflicts with existing Git branches or worktrees, it's highly recommended to clean up any remnants from previous runs.

You can use the `scripts/clean-demo.ps1` script to automate this process:

```powershell
./scripts/clean-demo.ps1
```

This script will attempt to remove the `roo-demo-worktree` worktree and delete the `feature/demo-branch` branch. The scripts are designed to handle scenarios where these resources might not exist, treating "not found" as a successful cleanup (i.e., nothing to clean up).

**Expected Cleanup Output:**

When running `clean-demo.ps1` (or when `run-demo.ps1` performs its initial cleanup), you can expect messages similar to these:

*   **If a resource exists and is removed/deleted:**
    ```
    Checking for existing worktree 'roo-demo-worktree'...
    Worktree 'roo-demo-worktree' found. Attempting to remove...
    Worktree 'roo-demo-worktree' removed or did not exist.
    Pruning git worktrees...
    Git worktrees pruned.
    Checking for existing branch 'feature/demo-branch'...
    Branch 'feature/demo-branch' found. Attempting to delete...
    Branch 'feature/demo-branch' deleted or did not exist.
    ```
*   **If a resource does not exist (no cleanup needed):**
    ```
    Checking for existing worktree 'roo-demo-worktree'...
    Worktree 'roo-demo-worktree' does not exist. No cleanup needed.
    Checking for existing branch 'feature/demo-branch'...
    Branch 'feature/demo-branch' does not exist. No cleanup needed.
    ```

**Interpreting Cleanup Output:**

*   Messages indicating "Worktree '...' removed or did not exist." or "Branch '...' deleted or did not exist." signify a successful cleanup operation for that specific resource, regardless of whether it was present initially.
*   The scripts will only report an error if an actual failure occurs during the `git` command execution that is not related to the resource not being found (e.g., permission issues, Git not installed correctly).

**When to use `clean-demo.ps1`:**
- Before running `run-demo.ps1` for the first time.
- If a previous `run-demo.ps1` execution was interrupted or failed.
- If you encounter "Failed to create worktree." or similar Git errors related to existing branches/worktrees, running `clean-demo.ps1` manually should resolve them.

## 3. Test Scenario: Step-by-Step Demonstration

The `scripts/run-demo.ps1` script automates the following steps to showcase Roo Master's features:

### Step 1: Create a new worktree for a feature branch

This step simulates a developer starting work on a new feature by creating a Git worktree.

**Command:**
```powershell
git worktree add -b feature/demo-branch roo-demo-worktree
```

**Expected Output:**
A new directory `roo-demo-worktree` will be created at the root level, containing a checkout of the `feature/demo-branch`.
### Project Structure within the Worktree

After Step 1, the `roo-demo-worktree` directory is created. Immediately following its creation, the `roo-demo-project` directory (located at the root of the main repository) is copied into the newly created worktree. This ensures that the demo project's files are available within the isolated worktree environment.

The resulting structure places the *contents* of `roo-demo-project` directly into `roo-demo-worktree/roo-demo-project`. This avoids double-nesting issues (e.g., `roo-demo-worktree/roo-demo-project/roo-demo-project`) and ensures all subsequent `npm` commands related to the demo project are executed from the correct single-level nested directory.

The copying is performed by the `run-demo.ps1` script using the following commands:
```powershell
$targetDemoProjectPath = Join-Path "roo-demo-worktree" "roo-demo-project"
if (-not (Test-Path $targetDemoProjectPath)) {
    New-Item -ItemType Directory -Path $targetDemoProjectPath | Out-Null
}
Copy-Item -Path "roo-demo-project\*" -Destination $targetDemoProjectPath -Recurse -Force
```

### Step 2: Start a tool container for that worktree (Simulated)

In a real Roo Master setup, a tool container (e.g., a Docker container with necessary build tools) would be started for the newly created worktree. For this demonstration, this step is simulated.

**Expected Output:**
A message indicating the simulation of tool container startup.

### Step 3: Register the MCP server with Roo (Assumed/Simulated)

Roo Master automatically detects and registers MCP servers. This step is assumed to be handled by the system or is simulated for the demonstration.

**Expected Output:**
A message indicating that the MCP server is registered.

### Step 4: Using the MCP tools (build.project, test.run, lint.fix)

This section demonstrates how Roo Master can leverage MCP tools for common development tasks.

#### 4.1: Install dependencies for `roo-demo-project`

The `run-demo.ps1` script will navigate to the `roo-demo-worktree/roo-demo-project` directory and execute `npm install`. This uses the direct `npm install` command, not an `npm run` script.

**Expected Output:**
Node.js dependencies will be installed in `roo-demo-worktree/roo-demo-project/node_modules`. You should see output indicating packages being added and resolved.

#### 4.2: Run `build.project` (`npm run build`)

This compiles the TypeScript code in the `roo-demo-project`. The `run-demo.ps1` script will ensure the `build` script exists and then execute `npm run build` within the `roo-demo-worktree/roo-demo-project` directory.

**Expected Output:**
TypeScript files will be compiled into JavaScript in the `roo-demo-worktree/roo-demo-project/dist` directory.

#### 4.3: Run `test.run` (`npm run test`)

This executes the unit tests for the `roo-demo-project`. The `run-demo.ps1` script will ensure the `test` script exists and then execute `npm run test` within the `roo-demo-worktree/roo-demo-project` directory.

**Expected Output:**
Jest test results, indicating successful test execution.

#### 4.4: Run `lint` (`npm run lint`) to show issues

This demonstrates the linter identifying intentional code style issues. The `run-demo.ps1` script will ensure the `lint` script exists and then execute `npm run lint` within the `roo-demo-worktree/roo-demo-project` directory.

**Expected Output:**
ESLint warnings/errors related to `no-unused-vars`, `prefer-const`, `semi`, and `quotes` in `src/index.ts`.

#### 4.5: Run `lint.fix` (`npm run lint:fix`) to fix issues

This shows the linter automatically correcting fixable code style issues. The `run-demo.ps1` script will ensure the `lint:fix` script exists and then execute `npm run lint:fix` within the `roo-demo-worktree/roo-demo-project` directory.

**Expected Output:**
ESLint will report that issues have been fixed, and the `src/index.ts` file will be modified to adhere to the linting rules.

### Step 5: Creating multiple parallel tracks (Simulated)

Roo Master supports managing multiple parallel development tracks. This step simulates the creation of new feature branches.

**Commands:**
```powershell
git checkout -b feature/track-a
git checkout -b feature/track-b master
git checkout feature/demo-branch
```

**Expected Output:**
Messages indicating the creation and switching of Git branches.

### Step 6: Merging tracks into integration branch (Simulated)

This step simulates the process of merging completed feature branches into an integration branch (e.g., `master`).

**Commands:**
```powershell
git checkout master
git merge feature/demo-branch --no-ff -m "Merge feature/demo-branch into master"
git branch -d feature/demo-branch
```

**Expected Output:**
Messages indicating Git branch checkout, merge, and deletion.

## 5. Troubleshooting Tips

### Git Issues

- **Conflicts with existing branches/worktrees**:
    - The `run-demo.ps1` script now includes improved automatic cleanup at the beginning. If you encounter issues related to existing `feature/demo-branch` or `roo-demo-worktree`, the `clean-demo.ps1` script is designed to handle these robustly. You can manually run `./scripts/clean-demo.ps1` as described in "2. Cleaning Up Previous Demo Runs".
- **"Failed to create worktree."**:
    - This error often indicates an existing `roo-demo-worktree` directory or `feature/demo-branch` that Git cannot manage. The `run-demo.ps1` script attempts to clean these up automatically. If the issue persists, manually run `./scripts/clean-demo.ps1`.
    - Ensure Git is properly installed and configured.
    - Verify that the current directory is a Git repository. If not, run `./scripts/init-demo.ps1` to initialize it.
- **"Failed to initialize git repository." / "Failed to create initial commit."**:
    - Ensure Git is installed and accessible in your PATH.
    - Check for any existing `.git` directory that might be corrupted. If so, delete it and try running `./scripts/init-demo.ps1` again.
    - Verify that you have write permissions in the current directory.

### Manual Worktree Cleanup and Troubleshooting

If the cleanup scripts (`clean-demo.ps1` or the initial cleanup in `run-demo.ps1`) fail to fully remove the worktree, you might need to perform manual steps.

- **Checking for orphaned worktree references**:
    Sometimes, Git might still have a reference to a worktree even if its directory has been manually deleted or is corrupted. To check for such orphaned references, use:
    ```powershell
    git worktree list
    ```
    If `roo-demo-worktree` appears in the list but the directory `roo-demo-worktree` does not exist on your file system, it's an orphaned reference.

- **Manually removing a worktree**:
    If `git worktree remove roo-demo-worktree --force` fails, or if you have an orphaned worktree reference, you can try the following:
    1.  **If the directory `roo-demo-worktree` still exists**:
        First, try to remove the directory manually. Ensure you are not inside the `roo-demo-worktree` directory when attempting to remove it.
        ```powershell
        Remove-Item -Recurse -Force roo-demo-worktree
        ```
        If you encounter "access denied" or "directory not empty" errors, ensure no processes (like VS Code, terminal, or other applications) are actively using files within `roo-demo-worktree`. Close any open applications that might be accessing it.
    2.  **After the directory is gone (or if it was already gone)**:
        Clean up Git's internal worktree references:
        ```powershell
        git worktree prune
        ```
        This command removes any stale or orphaned worktree entries from Git's internal list.

### Other Issues

- **"Failed to install dependencies for roo-demo-project."**: This indicates that `npm install` failed.
    - **Verify `npm` installation and internet connectivity**: Ensure Node.js and npm are correctly installed and that you have an active internet connection to download packages.
    - **Check `package.json`**: Navigate to `roo-demo-worktree/roo-demo-project` and inspect the `package.json` file for any syntax errors or incorrect dependency entries.
    - **Manually run `npm install`**:
        1.  Navigate to the `roo-demo-project` directory:
            ```powershell
            cd roo-demo-worktree/roo-demo-project
            ```
        2.  Run `npm install` directly:
            ```powershell
            npm install
            ```
            Examine the output for specific error messages (e.g., missing packages, network issues, permission problems).
    - **Clear npm cache**: Sometimes a corrupted npm cache can cause issues.
        ```powershell
        npm cache clean --force
        ```
        Then try `npm install` again.
    - **Check Node.js version**: Ensure your Node.js version is compatible with the project's dependencies.
### TypeScript Compilation Issues

- **"Build failed (npm run build failed with exit code X)."**: This indicates an issue with the TypeScript compilation.
    - **Check `tsconfig.json`**: Verify that `roo-demo-project/tsconfig.json` is correctly configured.
        - Ensure `rootDir` is set to `.` to include both `src` and `test` directories.
        - Confirm `outDir` is set to `./dist`.
        - Check that the `include` array contains `src/**/*.ts` and `test/**/*.ts`.
        - Confirm the following `compilerOptions` are present for robust compilation: `resolveJsonModule: true`, `allowSyntheticDefaultImports: true`, and `sourceMap: true`.
    - **Verify TypeScript Installation**: Ensure TypeScript is installed locally in `roo-demo-project` (check `package.json` `devDependencies`) and that `npm install` has been run.
    - **Review Compilation Errors**: The `run-demo.ps1` script now provides more detailed error messages for TypeScript compilation failures, highlighting specific `error TS` messages. Examine these messages to pinpoint syntax errors, type mismatches, or missing modules in your TypeScript files (`src/index.ts`, `test/index.test.ts`, etc.).

#### How to Verify TypeScript Configuration

To manually verify your TypeScript configuration and compilation:

1.  Navigate to the `roo-demo-project` directory:
    ```powershell
    cd roo-demo-project
    ```
2.  Install dependencies (if you haven't already):
    ```powershell
    npm install
    ```
3.  Run the TypeScript compiler:
    ```powershell
    npm run build
    ```
    If successful, you should see compiled JavaScript files in the `dist` directory. If there are errors, the output will indicate them.
- **"Tests failed (npm run test failed with exit code X)."**: This indicates an issue with the Jest tests. Review `roo-demo-project/test/index.test.ts` and `roo-demo-project/src/index.ts` for logical errors. Ensure Jest and its dependencies are correctly installed.
- **"Error: npm script 'lint' not found in..."**: This indicates the `lint` script is missing from `roo-demo-project/package.json`.
- **"Lint fix failed (npm run lint:fix failed with exit code X)."**: This indicates an issue during the linting fix process. Check `roo-demo-project/.eslintrc.js` for syntax errors. Ensure ESLint and its plugins are correctly installed.
- **"MCP server not found/registered."**: In a real scenario, ensure your MCP host is running and accessible to Roo Master.

### Path Handling Issues

A common issue, especially when dealing with nested projects or worktrees, can be path duplication, leading to errors like "package.json not found". This typically occurs when a script incorrectly concatenates an already absolute path with the current working directory.

-   **Identifying Path Duplication**:
    -   Look for error messages similar to: `"Error: package.json not found at C:\Users\YourUser\development\roo-master\roo-demo-worktree\roo-demo-project\roo-demo-worktree\roo-demo-project\package.json"`
    -   Notice the repetition of `roo-demo-worktree\roo-demo-project` in the path. This indicates that the base path was incorrectly joined with a relative path that already contained the full segment.
    -   The `run-demo.ps1` script includes `Write-Host "Current directory: $(Get-Location)"` statements. Pay close attention to these outputs. If you see paths like `C:\Users\YourUser\development\roo-master\roo-demo-worktree\roo-demo-project` and then a subsequent error indicating a path like `C:\Users\YourUser\development\roo-master\roo-demo-worktree\roo-demo-project\roo-demo-project\package.json`, it confirms path duplication.

-   **The Fix in `scripts/run-demo.ps1`**:
    -   The `Copy-Item` command in `scripts/run-demo.ps1` was updated to prevent double nesting of the `roo-demo-project` directory within the worktree. It now explicitly creates the target directory (`roo-demo-worktree/roo-demo-project`) and copies only the *contents* of the source `roo-demo-project` into it using `Copy-Item -Path "roo-demo-project\*" -Destination ...`.
    -   Additionally, the `Test-NpmScript` function in `scripts/run-demo.ps1` has been updated to correctly handle path parameters.
    -   It now checks if the provided path is already a full (rooted) path. If it is, the path is used directly.
    -   If the provided path is relative, it is correctly joined with the current working directory (`(Get-Location).Path`) to form the complete path.
    -   This prevents the redundant concatenation that caused path duplication.
    -   The `Run-NpmScript` function was also updated to pass the path directly to `Test-NpmScript`, relying on `Test-NpmScript`'s improved logic.

-   **Troubleshooting Path Problems**:
    1.  **Verify `Current directory:` output**: When running `run-demo.ps1`, carefully observe the "Current directory:" messages. Ensure that the script is operating in the expected directory at each step (e.g., `roo-demo-worktree` then `roo-demo-worktree\roo-demo-project`).
    2.  **Inspect `package.json` location**: If you get a "package.json not found" error, manually navigate to the reported path in your terminal and verify if `package.json` actually exists there. This can help confirm if the path itself is incorrect or if the file is genuinely missing.
### How to Verify Correct Demo Project Directory Structure

After `run-demo.ps1` has executed Step 1 (creating the worktree and copying the project), you can manually verify that the `roo-demo-project` contents are correctly placed within the worktree without double nesting.

1.  **Check the `roo-demo-worktree/roo-demo-project` directory**:
    Navigate to the `roo-demo-worktree` directory and then into `roo-demo-project`.
    ```powershell
    cd roo-demo-worktree/roo-demo-project
    ```
    Once inside, list its contents:
    ```powershell
    ls
    ```
    You should see files and directories like `package.json`, `src`, `test`, `tsconfig.json`, etc., directly within `roo-demo-worktree/roo-demo-project`. You should *not* see another `roo-demo-project` directory inside this one.

2.  **Verify `src` and `test` directories**:
    Confirm that `src` and `test` directories are directly under `roo-demo-worktree/roo-demo-project`.
    ```powershell
    Test-Path roo-demo-worktree/roo-demo-project/src
    Test-Path roo-demo-worktree/roo-demo-project/test
    ```
    Both commands should return `True`.

This verification ensures that the project structure is as expected for TypeScript compilation and npm script execution.
    3.  **Check script logic (if modifying)**: If you are modifying the scripts, ensure that any path manipulations use `Join-Path` correctly, and consider using `[System.IO.Path]::IsPathRooted($Path)` to differentiate between absolute and relative paths before joining.
    4.  **Clean and Rerun**: If path issues persist, a clean slate often helps. Run `./scripts/clean-demo.ps1` and then `./scripts/init-demo.ps1` before attempting to run `./scripts/run-demo.ps1` again.

### How to Verify Successful Installation and Path Handling

After running `npm install` (either via the demo script or manually), you can verify that dependencies were installed correctly:

1.  **Check for `node_modules` directory**:
    Navigate to `roo-demo-worktree/roo-demo-project`. There should be a `node_modules` directory present.
    ```powershell
    Test-Path roo-demo-worktree/roo-demo-project/node_modules
    ```
    This command should return `True`.

2.  **Check `package-lock.json` or `npm-shrinkwrap.json`**:
    These files should be updated or created in `roo-demo-worktree/roo-demo-project`, indicating that npm has locked down the dependency versions.

3.  **Run a simple npm command**:
    You can try running `npm list --depth=0` in `roo-demo-worktree/roo-demo-project` to see the top-level installed packages. This should list the direct dependencies from `package.json`.
    ```powershell
    cd roo-demo-worktree/roo-demo-project
    npm list --depth=0
    ```
    If this command runs without errors and lists your expected dependencies, it's a good sign that the installation was successful.

### Verifying Current Paths During Demo Execution

The `run-demo.ps1` script includes debug output to help you track the current working directory at various stages. Look for lines starting with "Current directory:" in the script's output.

For example, after the worktree is created and the script navigates into it, you should see output similar to:
```
Current directory: C:\Users\YourUser\development\roo-master\roo-demo-worktree
```

When the script then navigates into the `roo-demo-project` within the worktree to run `npm` commands, you should see:
```
Current directory: C:\Users\YourUser\development\roo-master\roo-demo-worktree\roo-demo-project
```

These debug messages confirm that the script is operating in the expected directories for each step, ensuring that `npm` commands are executed in the correct context.