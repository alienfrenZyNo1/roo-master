# Retry Handler Documentation

This document provides comprehensive documentation for the retry handler utilities implemented in the Roo Master VS Code extension. These utilities provide robust retry mechanisms with exponential backoff, circuit breaker integration, and configurable retry strategies.

## Overview

The retry handler system provides several key features:

- **Exponential Backoff**: Intelligent delay calculation with configurable backoff factors
- **Circuit Breaker Integration**: Combines retry logic with circuit breaker pattern for resilience
- **Configurable Retry Strategies**: Predefined configurations for different scenarios
- **Jitter Support**: Prevents thundering herd problems with randomized delays
- **Retry Result Tracking**: Comprehensive tracking of retry attempts and outcomes

## Core Components

### RetryHandler Class

The `RetryHandler` class provides static methods for implementing retry logic in your applications.

### Configuration Interfaces

#### RetryConfig

Configuration for retry behavior:

```typescript
interface RetryConfig {
    maxRetries: number;           // Maximum number of retry attempts
    initialDelayMs: number;      // Initial delay in milliseconds
    maxDelayMs: number;          // Maximum delay in milliseconds
    backoffFactor: number;       // Multiplier for exponential backoff
    jitter?: boolean;            // Whether to add randomness to delays
}
```

#### RetryOptions

Additional options for retry behavior:

```typescript
interface RetryOptions {
    context?: string;                                    // Context for error logging
    onRetry?: (error: any, attempt: number, delay: number) => void;  // Callback on each retry
    shouldRetry?: (error: any) => boolean;               // Custom retry condition
}
```

#### RetryResult

Result of a retry operation:

```typescript
interface RetryResult<T> {
    success: boolean;     // Whether the operation succeeded
    data?: T;            // Result data (if successful)
    error?: any;         // Error (if failed)
    attempts: number;    // Total number of attempts
    totalTimeMs: number; // Total time spent in milliseconds
}
```

## Key Methods

### `executeWithRetry(fn, config, options)`

Executes a function with retry logic and exponential backoff.

**Parameters:**
- `fn` () => Promise<T>: The function to execute
- `config` (Partial<RetryConfig>, optional): Retry configuration
- `options` (RetryOptions, optional): Additional retry options

**Returns:** Promise<RetryResult<T>>

**Example:**
```typescript
const result = await RetryHandler.executeWithRetry(
    async () => {
        return await dockerApi.listContainers();
    },
    {
        maxRetries: 5,
        initialDelayMs: 1000,
        maxDelayMs: 30000,
        backoffFactor: 2,
        jitter: true
    },
    {
        context: 'DockerAPI',
        onRetry: (error, attempt, delay) => {
            console.log(`Attempt ${attempt} failed, retrying in ${delay}ms`);
        }
    }
);

if (result.success) {
    console.log('Operation succeeded:', result.data);
} else {
    console.log('Operation failed after', result.attempts, 'attempts');
}
```

### `executeWithRetryAndCircuitBreaker(fn, resourceId, retryConfig, circuitConfig, options)`

Executes a function with both retry logic and circuit breaker protection.

**Parameters:**
- `fn` () => Promise<T>: The function to execute
- `resourceId` (string): Resource ID for circuit breaker
- `retryConfig` (Partial<RetryConfig>, optional): Retry configuration
- `circuitConfig` (CircuitBreakerConfig, optional): Circuit breaker configuration
- `options` (RetryOptions, optional): Additional retry options

**Returns:** Promise<RetryResult<T>>

**Example:**
```typescript
const result = await RetryHandler.executeWithRetryAndCircuitBreaker(
    async () => {
        return await mcpServer.executeTool(toolName, params);
    },
    'mcp-server',
    {
        maxRetries: 3,
        initialDelayMs: 2000
    },
    {
        failureThreshold: 3,
        resetTimeout: 30000
    },
    {
        context: 'MCPServer'
    }
);
```

### `createRetryFunction(config, options)`

Creates a reusable retry function with predefined configuration.

**Parameters:**
- `config` (Partial<RetryConfig>, optional): Retry configuration
- `options` (RetryOptions, optional): Additional retry options

**Returns:** (fn: () => Promise<T>) => Promise<RetryResult<T>>

**Example:**
```typescript
// Create a retry function for network operations
const networkRetry = RetryHandler.createRetryFunction(
    RetryHandler.getConfigForScenario('network'),
    {
        context: 'NetworkOperation',
        shouldRetry: RetryHandler.isRetryableError
    }
);

// Use the retry function
const result = await networkRetry(async () => {
    return await fetch('https://api.example.com/data');
});
```

### `createRetryFunctionWithCircuitBreaker(resourceId, retryConfig, circuitConfig, options)`

Creates a reusable retry function with circuit breaker protection.

**Parameters:**
- `resourceId` (string): Resource ID for circuit breaker
- `retryConfig` (Partial<RetryConfig>, optional): Retry configuration
- `circuitConfig` (CircuitBreakerConfig, optional): Circuit breaker configuration
- `options` (RetryOptions, optional): Additional retry options

**Returns:** (fn: () => Promise<T>) => Promise<RetryResult<T>>

**Example:**
```typescript
// Create a retry function with circuit breaker for database operations
const dbRetryWithCircuit = RetryHandler.createRetryFunctionWithCircuitBreaker(
    'database-connection',
    RetryHandler.getConfigForScenario('database'),
    {
        failureThreshold: 5,
        resetTimeout: 60000
    },
    {
        context: 'Database'
    }
);

// Use the retry function
const result = await dbRetryWithCircuit(async () => {
    return await database.query('SELECT * FROM users');
});
```

### `isRetryableError(error)`

Determines if an error is retryable based on common patterns.

**Parameters:**
- `error` (any): The error to evaluate

**Returns:** boolean

**Retryable Error Patterns:**
- Connection refused
- Timeout errors
- Network errors
- Temporary failures
- Service unavailable
- Rate limit exceeded
- Gateway timeouts

**Example:**
```typescript
try {
    await someOperation();
} catch (error) {
    if (RetryHandler.isRetryableError(error)) {
        // Retry the operation
        const result = await RetryHandler.executeWithRetry(someOperation);
    } else {
        // Handle non-retryable error
        throw error;
    }
}
```

### `getConfigForScenario(scenario)`

Gets preconfigured retry settings for common scenarios.

**Parameters:**
- `scenario` ('network' | 'database' | 'file' | 'container'): The scenario type

**Returns:** Partial<RetryConfig>

**Predefined Configurations:**

#### Network Scenario
```typescript
{
    maxRetries: 5,
    initialDelayMs: 1000,
    maxDelayMs: 60000,
    backoffFactor: 2,
    jitter: true
}
```

#### Database Scenario
```typescript
{
    maxRetries: 3,
    initialDelayMs: 500,
    maxDelayMs: 10000,
    backoffFactor: 2,
    jitter: false
}
```

#### File Scenario
```typescript
{
    maxRetries: 2,
    initialDelayMs: 100,
    maxDelayMs: 1000,
    backoffFactor: 1.5,
    jitter: false
}
```

#### Container Scenario
```typescript
{
    maxRetries: 3,
    initialDelayMs: 2000,
    maxDelayMs: 30000,
    backoffFactor: 2,
    jitter: true
}
```

**Example:**
```typescript
const containerConfig = RetryHandler.getConfigForScenario('container');
const result = await RetryHandler.executeWithRetry(
    async () => {
        return await docker.startContainer(containerName);
    },
    containerConfig,
    {
        context: 'DockerContainer'
    }
);
```

## Integration Patterns

### 1. Basic Retry Pattern

```typescript
export async function fetchWithRetry(url: string): Promise<any> {
    const result = await RetryHandler.executeWithRetry(
        async () => {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            return response.json();
        },
        RetryHandler.getConfigForScenario('network'),
        {
            context: 'FetchAPI',
            shouldRetry: RetryHandler.isRetryableError
        }
    );

    if (!result.success) {
        throw new Error(`Failed to fetch ${url} after ${result.attempts} attempts`);
    }

    return result.data;
}
```

### 2. Retry with Circuit Breaker Pattern

```typescript
export class DockerService {
    private static createContainerRetry() {
        return RetryHandler.createRetryFunctionWithCircuitBreaker(
            'docker-container-api',
            RetryHandler.getConfigForScenario('container'),
            {
                failureThreshold: 3,
                resetTimeout: 60000
            },
            {
                context: 'DockerService'
            }
        );
    }

    async createContainer(imageName: string, containerName: string): Promise<string> {
        const retry = DockerService.createContainerRetry();
        
        const result = await retry(async () => {
            return await docker.createContainer({
                Image: imageName,
                name: containerName
            });
        });

        if (!result.success) {
            throw new Error(`Failed to create container after ${result.attempts} attempts`);
        }

        return result.data;
    }
}
```

### 3. Custom Retry Condition Pattern

```typescript
export async function uploadFileWithRetry(filePath: string, uploadUrl: string): Promise<void> {
    const result = await RetryHandler.executeWithRetry(
        async () => {
            const stats = await fs.promises.stat(filePath);
            const fileSize = stats.size;
            
            const response = await fetch(uploadUrl, {
                method: 'PUT',
                body: fs.createReadStream(filePath),
                headers: {
                    'Content-Length': fileSize.toString()
                }
            });

            if (!response.ok) {
                throw new Error(`Upload failed: ${response.statusText}`);
            }
        },
        {
            maxRetries: 3,
            initialDelayMs: 2000,
            backoffFactor: 2
        },
        {
            context: 'FileUpload',
            shouldRetry: (error) => {
                // Custom retry logic
                const errorMessage = error.message.toLowerCase();
                return RetryHandler.isRetryableError(error) ||
                       errorMessage.includes('upload failed') ||
                       errorMessage.includes('connection reset');
            },
            onRetry: (error, attempt, delay) => {
                console.log(`Upload attempt ${attempt} failed, retrying in ${delay}ms: ${error.message}`);
            }
        }
    );

    if (!result.success) {
        throw new Error(`Failed to upload file after ${result.attempts} attempts`);
    }
}
```

### 4. Progressive Retry Pattern

```typescript
export async function progressiveRetryOperation<T>(
    operation: () => Promise<T>,
    stages: Array<{
        maxRetries: number;
        delayMs: number;
        condition?: (error: any) => boolean;
    }>
): Promise<RetryResult<T>> {
    for (const stage of stages) {
        const result = await RetryHandler.executeWithRetry(
            operation,
            {
                maxRetries: stage.maxRetries,
                initialDelayMs: stage.delayMs,
                maxDelayMs: stage.delayMs,
                backoffFactor: 1, // No exponential backoff within stages
                jitter: false
            },
            {
                shouldRetry: stage.condition || RetryHandler.isRetryableError
            }
        );

        if (result.success) {
            return result;
        }
    }

    return {
        success: false,
        error: new Error('All retry stages failed'),
        attempts: stages.reduce((sum, stage) => sum + stage.maxRetries + 1, 0),
        totalTimeMs: 0
    };
}

// Usage
const result = await progressiveRetryOperation(
    async () => await someOperation(),
    [
        { maxRetries: 2, delayMs: 100 },    // Fast retries for transient issues
        { maxRetries: 3, delayMs: 1000 },   // Medium retries for temporary issues
        { maxRetries: 2, delayMs: 5000 }    // Slow retries for persistent issues
    ]
);
```

## Best Practices

### 1. Choosing Retry Parameters

#### For Network Operations
- Use higher retry counts (5-7 attempts)
- Start with shorter delays (1-2 seconds)
- Use exponential backoff with jitter
- Implement proper timeout handling

#### For Database Operations
- Use moderate retry counts (3-5 attempts)
- Start with medium delays (500ms-1s)
- Consider connection pool constraints
- Avoid retrying on constraint violations

#### For File Operations
- Use lower retry counts (2-3 attempts)
- Start with short delays (100-500ms)
- Retry only on file system contention
- Don't retry on permission errors

#### For Container Operations
- Use moderate retry counts (3-5 attempts)
- Start with longer delays (2-5 seconds)
- Consider container startup time
- Implement proper health checks

### 2. Error Handling

```typescript
// Always check retry result
const result = await RetryHandler.executeWithRetry(someOperation);

if (!result.success) {
    // Log detailed information about the failure
    console.error(`Operation failed after ${result.attempts} attempts`);
    console.error(`Total time spent: ${result.totalTimeMs}ms`);
    console.error(`Final error: ${result.error?.message}`);
    
    // Re-throw or handle appropriately
    throw result.error;
}
```

### 3. Monitoring and Observability

```typescript
// Add custom retry callbacks for monitoring
const result = await RetryHandler.executeWithRetry(
    someOperation,
    retryConfig,
    {
        onRetry: (error, attempt, delay) => {
            // Log retry attempts to monitoring system
            monitoring.increment('retry.attempts');
            monitoring.timing('retry.delay', delay);
            
            console.log(`Retry attempt ${attempt} for ${error.message}`);
        },
        context: 'MyOperation'
    }
);

// Log final results
if (result.success) {
    monitoring.timing('operation.success', result.totalTimeMs);
    monitoring.increment('operation.success_count');
} else {
    monitoring.timing('operation.failure', result.totalTimeMs);
    monitoring.increment('operation.failure_count');
}
```

### 4. Circuit Breaker Integration

Always use circuit breakers for external service calls:

```typescript
// Good: Retry with circuit breaker
const result = await RetryHandler.executeWithRetryAndCircuitBreaker(
    async () => await externalService.call(),
    'external-service',
    retryConfig,
    circuitConfig
);

// Avoid: Retry without circuit breaker for external services
const result = await RetryHandler.executeWithRetry(
    async () => await externalService.call(),
    retryConfig
);
```

## Testing Retry Logic

### 1. Testing Basic Retry Behavior

```typescript
jest.mock('./util/retryHandler');

test('should retry on failure and eventually succeed', async () => {
    let attempts = 0;
    const mockFn = jest.fn()
        .mockImplementationOnce(() => Promise.reject(new Error('Failed')))
        .mockImplementationOnce(() => Promise.reject(new Error('Failed')))
        .mockImplementationOnce(() => Promise.resolve('success'));

    const result = await RetryHandler.executeWithRetry(mockFn, {
        maxRetries: 3,
        initialDelayMs: 10  // Short delay for testing
    });

    expect(result.success).toBe(true);
    expect(result.data).toBe('success');
    expect(result.attempts).toBe(3);
    expect(mockFn).toHaveBeenCalledTimes(3);
});
```

### 2. Testing Retry Failure

```typescript
test('should fail after max retries', async () => {
    const mockFn = jest.fn()
        .mockRejectedValue(new Error('Persistent error'));

    const result = await RetryHandler.executeWithRetry(mockFn, {
        maxRetries: 2,
        initialDelayMs: 10
    });

    expect(result.success).toBe(false);
    expect(result.error).toBeDefined();
    expect(result.attempts).toBe(3); // Initial + 2 retries
    expect(mockFn).toHaveBeenCalledTimes(3);
});
```

### 3. Testing Custom Retry Conditions

```typescript
test('should respect custom retry condition', async () => {
    const mockFn = jest.fn()
        .mockRejectedValue(new Error('Non-retryable error'));

    const result = await RetryHandler.executeWithRetry(
        mockFn,
        { maxRetries: 3, initialDelayMs: 10 },
        {
            shouldRetry: (error) => error.message.includes('retryable')
        }
    );

    expect(result.success).toBe(false);
    expect(result.attempts).toBe(1); // No retries due to custom condition
    expect(mockFn).toHaveBeenCalledTimes(1);
});
```

## Performance Considerations

### 1. Memory Usage

The retry handler is designed to be memory-efficient:
- No accumulation of error objects beyond the last error
- Minimal state tracking during retry operations
- Cleanup of temporary objects after completion

### 2. CPU Usage

- Exponential backoff calculations are lightweight
- Jitter calculations use simple randomization
- No complex algorithms or heavy computations

### 3. Network Impact

- Jitter helps prevent thundering herd problems
- Exponential backoff reduces request frequency during outages
- Circuit breaker prevents hammering failing services

## Troubleshooting

### 1. Common Issues

#### Too Many Retries
- Check if `maxRetries` is set appropriately
- Verify that `shouldRetry` condition is not too permissive
- Consider implementing more specific error handling

#### Too Long Delays
- Review `initialDelayMs` and `maxDelayMs` settings
- Check `backoffFactor` for aggressive exponential growth
- Consider using scenario-specific configurations

#### Circuit Breaker Not Opening
- Verify `failureThreshold` configuration
- Check that `expectedExceptionPredicate` is correctly configured
- Ensure monitoring period is appropriate for your use case

### 2. Debug Logging

Enable debug logging to trace retry behavior:

```typescript
const result = await RetryHandler.executeWithRetry(
    someOperation,
    retryConfig,
    {
        onRetry: (error, attempt, delay) => {
            console.debug(`Retry attempt ${attempt + 1}/${retryConfig.maxRetries + 1}`);
            console.debug(`Error: ${error.message}`);
            console.debug(`Delay: ${delay}ms`);
            console.debug(`Next attempt will be at: ${new Date(Date.now() + delay).toISOString()}`);
        }
    }
);
```

## Conclusion

The retry handler provides a robust, configurable system for implementing retry logic in the Roo Master extension. By following the patterns and best practices outlined in this document, you can build resilient components that handle temporary failures gracefully while maintaining good performance and user experience.

Key takeaways:
- Use scenario-specific configurations for different types of operations
- Always integrate with circuit breakers for external service calls
- Implement proper monitoring and logging for retry operations
- Test retry behavior thoroughly, including both success and failure scenarios
- Consider the performance impact of retry strategies on your system