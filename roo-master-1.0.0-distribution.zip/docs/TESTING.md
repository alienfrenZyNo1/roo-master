# Roo Master Project Testing Guide

This document provides a comprehensive guide to testing the Roo Master project, covering manual test steps for major functionalities, simulating failures, parallel execution scenarios, and integration/end-to-end testing procedures.

## 1. Manual Test Steps for Major Functionality

### 1.1. VS Code Extension Commands

These steps verify the core functionalities exposed through the VS Code extension.

#### 1.1.1. Create Worktree
1.  Open a Git repository in VS Code.
2.  Open the Command Palette (`Ctrl+Shift+P` or `Cmd+Shift+P`).
3.  Search for and select "Roo Master: Create Worktree (new branch)".
4.  Enter a new, unique branch name (e.g., `feature/my-new-feature`).
5.  Enter a worktree directory name (e.g., `my-feature-worktree`).
6.  **Expected Result:** A new worktree is created in a sibling directory to your main repository, on the specified branch. A success message should appear, and the new worktree should be visible in the "Roo Master Explorer" tree view.

#### 1.1.2. Open Worktree
1.  Ensure you have at least one existing worktree (created using the step above or manually).
2.  Open the Command Palette.
3.  Search for and select "Roo Master: Open Worktree".
4.  Select an existing worktree from the quick pick list.
5.  **Expected Result:** A new VS Code window opens with the selected worktree as the workspace folder.

#### 1.1.3. Start Tool Container
1.  Ensure Docker Desktop or Docker daemon is running.
2.  Open the Command Palette.
3.  Search for and select "Roo Master: Start Tool Container(s)".
4.  Enter a Docker image name (e.g., `tool-image` if you've built it locally).
5.  Enter a container name (e.g., `my-dev-container`).
6.  (Optional) Enter port bindings (e.g., `8080:80`).
7.  **Expected Result:** A Docker container with the specified name and image starts. A success message should appear, and the container should be visible in the "Roo Master Explorer" tree view.

#### 1.1.4. Stop Tool Container
1.  Ensure you have at least one running tool container.
2.  Open the Command Palette.
3.  Search for and select "Roo Master: Stop Tool Container(s)".
4.  Select a running container from the quick pick list.
5.  **Expected Result:** The selected Docker container stops. A success message should appear, and the container's status in the "Roo Master Explorer" tree view should update to inactive or disappear.

#### 1.1.5. Register MCP Server
1.  Open a worktree in VS Code.
2.  Open the Command Palette.
3.  Search for and select "Roo Master: Register MCP Server".
4.  If prompted, select the worktree for which to register the server.
5.  **Expected Result:** An MCP Host Server instance is launched for the selected worktree on an available port. A success message should appear, and the MCP Server status in the "Roo Master Explorer" tree view should indicate it's active with a port number.

#### 1.1.6. Show Logs
1.  Open the Command Palette.
2.  Search for and select "Roo Master: Show Logs".
3.  **Expected Result:** The "Roo Master" output channel opens in the VS Code Output panel, displaying logs from the extension and any active MCP servers.

### 1.2. MCP Host Tools

These steps verify the functionality of the tools exposed by the MCP Host Server. These typically require an active MCP server and a running tool container.

#### 1.2.1. `build.project`
1.  Ensure an MCP server is registered and running for your worktree, and a tool container is active and mounted to your worktree's `/work` directory.
2.  Use the `use_mcp_tool` command (or equivalent in the agent interface) with `server_name: <your-mcp-server-name>` and `tool_name: build.project`.
3.  Provide inputs: `{"install": true, "target": "dev"}` (or other valid options).
4.  **Expected Result:** The project within the container's `/work` directory is built. The tool output should indicate success and display build logs.

#### 1.2.2. `test.run`
1.  Ensure an MCP server is registered and running for your worktree, and a tool container is active and mounted to your worktree's `/work` directory.
2.  Use the `use_mcp_tool` command with `server_name: <your-mcp-server-name>` and `tool_name: test.run`.
3.  (Optional) Provide inputs: `{"pattern": "src/components/MyComponent.test.ts"}`.
4.  **Expected Result:** Tests are executed within the container. The tool output should indicate test results (pass/fail) and display test logs.

#### 1.2.3. `lint.fix`
1.  Ensure an MCP server is registered and running for your worktree, and a tool container is active and mounted to your worktree's `/work` directory.
2.  Use the `use_mcp_tool` command with `server_name: <your-mcp-server-name>` and `tool_name: lint.fix`.
3.  **Expected Result:** Linting rules are applied and fixed within the container's `/work` directory. The tool output should indicate success and display linting logs. Verify file changes in your worktree.

#### 1.2.4. Demo Project Testing
1.  Navigate to the `roo-demo-project` directory.
2.  Run `npm install` to install dependencies.
3.  Execute the test suite: `npm test`
4.  **Expected Result:** The test should execute successfully and pass. The test verifies that the `greet` function correctly outputs "Hello, World!" to the console using Jest testing framework.

## 2. Simulating Failures and Error Conditions

Testing error handling is crucial for a robust system.

-   **Docker Daemon Not Running:**
    -   **Steps:** Stop Docker Desktop/daemon. Attempt to "Start Tool Container(s)".
    -   **Expected:** An error message indicating Docker is not running or cannot be reached.
-   **Invalid Docker Image/Container Name:**
    -   **Steps:** Attempt to "Start Tool Container(s)" with a non-existent image name or a container name that already exists.
    -   **Expected:** Appropriate error messages from Docker.
-   **Port Conflicts:**
    -   **Steps:** Manually start a process on a port (e.g., 8000) that Roo's MCP server might try to use. Then attempt to "Register MCP Server".
    -   **Expected:** The MCP server should find another available port, or an error if no ports are available in the range.
-   **Build/Test/Lint Failures within Container:**
    -   **Steps:** Introduce a syntax error or a failing test into your project within a worktree. Run `build.project`, `test.run`, or `lint.fix` via the MCP server.
    -   **Expected:** The tool execution should report failure (`success: false`) and the logs should contain the error output from the build/test/lint process.
-   **Worktree Creation Failures:**
    -   **Steps:** Attempt to "Create Worktree" with a branch name that already exists or a directory name that is already taken.
    -   **Expected:** An error message from Git or the extension indicating the conflict.

## 3. Test Scenarios for Parallel Track Execution

Roo Master is designed for parallel development using worktrees.

-   **Scenario 1: Multiple Worktrees, One Container:**
    -   Create two worktrees (e.g., `feature-A`, `feature-B`).
    -   Open `feature-A` in VS Code, register MCP server, start a tool container.
    -   Open `feature-B` in a *separate* VS Code window.
    -   Attempt to run `build.project` in `feature-B` using the *same* container name.
    -   **Expected:** The `build.project` command should execute successfully within the container, operating on the files mounted from `feature-B` (assuming the container was started with the correct worktree mounted). This highlights the importance of mounting the correct worktree to `/work`.
-   **Scenario 2: Multiple Worktrees, Dedicated Containers:**
    -   Create two worktrees (`feature-A`, `feature-B`).
    -   Open `feature-A`, register MCP server, start `container-A` mounted to `feature-A`.
    -   Open `feature-B`, register MCP server, start `container-B` mounted to `feature-B`.
    -   Run `test.run` in `feature-A` (using `container-A`) and `lint.fix` in `feature-B` (using `container-B`) simultaneously.
    -   **Expected:** Both operations should run concurrently and independently without interference. Changes made by `lint.fix` in `feature-B` should not affect `feature-A`.
-   **Scenario 3: Worktree Isolation:**
    -   Make a change in `feature-A` (e.g., modify a file).
    -   Switch to `feature-B` (in a different VS Code window or by opening it).
    -   **Expected:** The changes from `feature-A` should not be visible in `feature-B` unless explicitly merged via Git.

## 4. Testing Procedures for Integration and Merge Flow

-   **Component Integration Testing:**
    -   Make a change in the `vscode-ext` package (e.g., a new command).
    -   Make a corresponding change in `mcp-host` (e.g., a new tool).
    -   Rebuild both packages.
    -   Test the new command in VS Code, ensuring it correctly invokes the new MCP tool.
-   **Worktree to Main Branch Merge:**
    -   Create a worktree, make changes, commit them.
    -   Test all functionalities within the worktree (build, test, lint).
    -   Switch back to the main branch.
    -   Merge the worktree branch into the main branch.
    -   **Expected:** The changes are successfully merged. The main branch now reflects the worktree's changes. All functionalities on the main branch should still work correctly.

## 5. End-to-End Testing Procedures

This procedure covers the entire lifecycle of a development task using Roo Master.

### 5.1. Manual End-to-End Testing

1.  **Initial Setup:**
    -   Ensure Docker is running.
    -   Build the `tool-image` Docker image (`docker build -t tool-image packages/tool-image`).
    -   Install the Roo Master VS Code extension.
2.  **Create a New Feature Worktree:**
    -   Use "Roo Master: Create Worktree (new branch)" to create a worktree for a new feature (e.g., `feature/new-component`).
3.  **Open the Worktree:**
    -   Use "Roo Master: Open Worktree" to open the newly created worktree in a new VS Code window.
4.  **Register MCP Server:**
    -   In the new worktree window, use "Roo Master: Register MCP Server". Verify the server is active in the Explorer.
5.  **Start Tool Container:**
    -   Use "Roo Master: Start Tool Container(s)" with `tool-image` and a unique container name (e.g., `my-feature-container`). Ensure the container is running and visible.
6.  **Develop and Test:**
    -   Make some code changes in the worktree.
    -   Use the MCP tools (via agent or manual `use_mcp_tool` calls) to:
        -   `build.project`: Verify the project builds successfully.
        -   `test.run`: Run tests and ensure they pass.
        -   `lint.fix`: Apply linting fixes and verify code style.
    -   Simulate a failure (e.g., introduce a syntax error) and verify that `build.project` reports an error. Fix the error.
7.  **Verify Isolation:**
    -   Open your main repository (original VS Code window). Verify that changes made in the worktree are not present in the main branch.
8.  **Clean Up (Optional but Recommended for Testing):**
    -   Stop the tool container using "Roo Master: Stop Tool Container(s)".
    -   Close the worktree VS Code window.
    -   Use the clean-demo script to remove worktrees: `.\scripts\clean-demo.ps1`

### 5.2. Automated End-to-End Testing

The project includes automated E2E testing scripts for systematic testing:

1.  **E2E Setup:**
    -   Run the setup script to create a clean test repository: `node scripts/e2e-setup.js`
    -   This creates a `test-repo/` directory with initialized Git repository
    -   The script sets up basic Git configuration and creates an initial commit

2.  **Demo Testing:**
    -   Run the demo setup: `.\scripts\init-demo.ps1`
    -   Execute the demo: `.\scripts\run-demo.ps1`
    -   Verify all operations complete successfully

3.  **E2E Teardown:**
    -   After testing completes, run the cleanup script: `node scripts/e2e-teardown.js`
    -   This removes the test repository and all associated artifacts
    -   Also run the demo cleanup: `.\scripts\clean-demo.ps1`

### 5.3. Test Project Validation

The `roo-demo-project` serves as a testbed for validating the system:

1.  **Project Structure:**
    -   Contains a simple TypeScript project with Jest testing
    -   Includes a `greet` function that outputs to console
    -   Has proper TypeScript configuration and package.json setup

2.  **Test Execution:**
    -   Navigate to `roo-demo-project`
    -   Install dependencies: `npm install`
    -   Run tests: `npm test`
    -   **Expected Result:** Test passes with console output verification

3.  **Integration Testing:**
    -   The demo scripts use this project to validate MCP tool functionality
    -   Tests verify that TypeScript imports work correctly
    -   Ensures the project can be built and tested within Docker containers