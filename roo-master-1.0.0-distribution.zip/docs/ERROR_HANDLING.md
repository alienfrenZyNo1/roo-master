# Error Handling Utilities

This document provides comprehensive documentation for the error handling utilities implemented in the Roo Master VS Code extension. These utilities provide centralized error management, recovery strategies, and circuit breaker patterns to ensure robust operation.

## Overview

The error handling system provides several key features:

- **Centralized Error Management**: Consistent error logging and user notification
- **Recovery Strategies**: Automatic and manual error recovery mechanisms
- **Circuit Breaker Pattern**: Prevents cascading failures in distributed systems
- **Error History**: Tracking and analysis of errors over time
- **Validation Utilities**: Common validation functions with error handling

## Core Components

### ErrorHandler Class

The `ErrorHandler` class is the central component for error management in the extension.

#### Key Methods

##### `handleError(error, options)`

Handles an error with consistent logging and user notification.

**Parameters:**
- `error` (Error | string): The error to handle
- `options` (ErrorOptions): Configuration for error handling

**ErrorOptions:**
- `showUser` (boolean, default: true): Whether to show the error to the user
- `logLevel` ('info' | 'warn' | 'error' | 'debug', default: 'error'): Logging level
- `userMessage` (string, optional): Custom message to show to the user
- `context` (string, default: 'Extension'): Context where the error occurred
- `recoveryActions` (RecoveryAction[], optional): Manual recovery actions to offer

**Example:**
```typescript
await ErrorHandler.handleError(
    new Error('Failed to start container'),
    {
        showUser: true,
        logLevel: 'error',
        context: 'DockerContainer',
        userMessage: 'Unable to start the development container'
    }
);
```

##### `wrapAsync(fn, context, userMessage)`

Wraps an async function with error handling.

**Parameters:**
- `fn` () => Promise<T>: The function to wrap
- `context` (string): Context for error handling
- `userMessage` (string, optional): Custom message to show on error

**Returns:** Promise<T> - The result of the function or throws if an error occurs

**Example:**
```typescript
const result = await ErrorHandler.wrapAsync(
    async () => {
        return await dockerContainer.start();
    },
    'DockerContainer',
    'Failed to start Docker container'
);
```

##### `validateRequired(value, paramName, context)`

Validates that a value is not null or undefined.

**Parameters:**
- `value` (any): The value to validate
- `paramName` (string): Name of the parameter (for error message)
- `context` (string, optional): Context of the validation

**Throws:** Error if validation fails

**Example:**
```typescript
ErrorHandler.validateRequired(containerName, 'containerName', 'DockerContainer');
```

##### `validatePath(path, pathType, context)`

Validates that a path exists and is accessible.

**Parameters:**
- `path` (string): Path to validate
- `pathType` ('file' | 'directory', default: 'file'): Type of path
- `context` (string, optional): Context of the validation

**Throws:** Error if validation fails

**Example:**
```typescript
ErrorHandler.validatePath('/path/to/container', 'directory', 'DockerContainer');
```

##### `createError(message, code, details)`

Creates a standardized error response.

**Parameters:**
- `message` (string): Error message
- `code` (string, optional): Error code
- `details` (any, optional): Additional error details

**Returns:** Standardized error object

**Example:**
```typescript
const errorResponse = ErrorHandler.createError(
    'Container not found',
    'CONTAINER_NOT_FOUND',
    { containerId: 'abc123' }
);
```

##### `createSuccess(data)`

Creates a standardized success response.

**Parameters:**
- `data` (T): Success data

**Returns:** Standardized success object

**Example:**
```typescript
const successResponse = ErrorHandler.createSuccess({ containerId: 'abc123' });
```

### CircuitBreaker Class

Implements the circuit breaker pattern to prevent cascading failures.

#### Constructor

```typescript
constructor(resourceId: string, config?: CircuitBreakerConfig)
```

**CircuitBreakerConfig:**
- `failureThreshold` (number, default: 5): Number of failures before opening circuit
- `resetTimeout` (number, default: 60000): Time to wait before attempting reset (ms)
- `monitoringPeriod` (number, default: 60000): Time period to monitor failures (ms)
- `expectedExceptionPredicate` (function, default: all exceptions): Predicate to determine if an exception should count as a failure

#### Key Methods

##### `execute(action)`

Executes an action with circuit breaker protection.

**Parameters:**
- `action` () => Promise<T>: The action to execute

**Returns:** Promise<T> - Result of the action

**Throws:** Error if circuit is open or action fails

**Example:**
```typescript
const circuitBreaker = ErrorHandler.getCircuitBreaker('docker-api', {
    failureThreshold: 3,
    resetTimeout: 30000
});

try {
    const result = await circuitBreaker.execute(async () => {
        return await dockerApi.listContainers();
    });
} catch (error) {
    // Handle circuit breaker open or API failure
}
```

##### `getState()`

Gets the current state of the circuit breaker.

**Returns:** CircuitState (CLOSED | OPEN | HALF_OPEN)

##### `getFailureCount()`

Gets the current failure count.

**Returns:** number

##### `reset()`

Resets the circuit breaker to closed state.

### Recovery Strategies

The system provides both automatic and manual recovery strategies for common error scenarios.

#### CommonRecoveryStrategies

Predefined recovery strategies for common error patterns:

##### RetryStrategy

Handles transient failures like network issues or timeouts.

**Error Patterns:**
- Connection refused
- Timeout errors
- Network errors
- Temporary unavailability

**Applies to:** All contexts

##### CleanupStrategy

Handles resource conflicts and cleanup needs.

**Error Patterns:**
- Resource already in use
- Resource busy
- Locked resources

**Applies to:** Container, Worktree, and MCP contexts

##### ReconnectStrategy

Handles connection-related failures.

**Error Patterns:**
- Connection lost
- Disconnected
- Connection reset

**Applies to:** MCP, Docker, and Server contexts

##### FallbackStrategy

Handles service unavailability.

**Error Patterns:**
- Service unavailable
- Not found
- Service down

**Applies to:** All contexts

#### Custom Recovery Strategies

You can create custom recovery strategies:

```typescript
const customStrategy: RecoveryStrategy = {
    name: 'custom-recovery',
    description: 'Custom recovery logic',
    canHandle: (error: Error | string) => {
        const errorMessage = error instanceof Error ? error.message : error;
        return errorMessage.includes('specific-error');
    },
    appliesToContext: (context: string) => {
        return context.includes('SpecificComponent');
    },
    recover: async (error: Error | string, context: ErrorContext) => {
        // Implement recovery logic
        return true; // Return true if recovery successful
    }
};

ErrorHandler.registerRecoveryStrategy(customStrategy);
```

#### Manual Recovery Actions

You can provide manual recovery actions to users:

```typescript
const recoveryActions: RecoveryAction[] = [
    {
        id: 'retry',
        label: 'Retry Operation',
        callback: async () => {
            // Retry logic
            return true;
        },
        description: 'Attempts the operation again'
    },
    {
        id: 'cleanup',
        label: 'Clean Up Resources',
        callback: async () => {
            // Cleanup logic
            return true;
        },
        description: 'Cleans up locked resources'
    }
];

await ErrorHandler.handleError(error, {
    recoveryActions
});
```

## Error Context and History

### ErrorContext Interface

Provides context information for errors:

```typescript
interface ErrorContext {
    component: string;
    operation?: string;
    timestamp: number;
    errorId: string;
    recoveryAttempted?: boolean;
    recoverySuccessful?: boolean;
}
```

### Error History Management

##### `getErrorHistory()`

Gets the complete error history.

**Returns:** Map<string, ErrorContext>

##### `clearErrorHistory()`

Clears the error history.

## Best Practices

### 1. Error Handling Patterns

#### Basic Error Handling
```typescript
try {
    // Operation that might fail
    await riskyOperation();
} catch (error) {
    await ErrorHandler.handleError(error, {
        context: 'MyComponent',
        userMessage: 'Failed to complete operation'
    });
}
```

#### With Recovery Actions
```typescript
const recoveryActions: RecoveryAction[] = [
    {
        id: 'retry',
        label: 'Retry',
        callback: async () => {
            await riskyOperation();
            return true;
        }
    }
];

await ErrorHandler.handleError(error, {
    context: 'MyComponent',
    recoveryActions
});
```

#### With Circuit Breaker
```typescript
const circuitBreaker = ErrorHandler.getCircuitBreaker('my-service');

try {
    const result = await circuitBreaker.execute(async () => {
        return await myServiceCall();
    });
} catch (error) {
    await ErrorHandler.handleError(error, {
        context: 'MyService'
    });
}
```

### 2. Validation Patterns

#### Required Parameter Validation
```typescript
function myFunction(requiredParam: string) {
    ErrorHandler.validateRequired(requiredParam, 'requiredParam', 'myFunction');
    // Function logic
}
```

#### Path Validation
```typescript
async function processFile(filePath: string) {
    ErrorHandler.validatePath(filePath, 'file', 'processFile');
    // File processing logic
}
```

### 3. Response Standardization

#### Error Response
```typescript
function myOperation(): Promise<{ success: boolean; data?: any; error?: any }> {
    try {
        const result = await doSomething();
        return ErrorHandler.createSuccess(result);
    } catch (error) {
        return ErrorHandler.createError(
            'Operation failed',
            'OPERATION_FAILED',
            { originalError: error }
        );
    }
}
```

## Integration Examples

### 1. Docker Container Management

```typescript
export async function startContainer(containerName: string): Promise<string> {
    const circuitBreaker = ErrorHandler.getCircuitBreaker('docker-api', {
        failureThreshold: 3,
        resetTimeout: 30000
    });

    return ErrorHandler.wrapAsync(async () => {
        ErrorHandler.validateRequired(containerName, 'containerName', 'startContainer');
        
        return await circuitBreaker.execute(async () => {
            const containerId = await docker.start(containerName);
            return containerId;
        });
    }, 'DockerContainer', 'Failed to start Docker container');
}
```

### 2. MCP Server Management

```typescript
export async function registerMCPServer(worktreePath: string): Promise<void> {
    const recoveryActions: RecoveryAction[] = [
        {
            id: 'retry',
            label: 'Retry Registration',
            callback: async () => {
                await registerMCPServer(worktreePath);
                return true;
            }
        },
        {
            id: 'cleanup',
            label: 'Clean Up Server Files',
            callback: async () => {
                await cleanupServerFiles(worktreePath);
                return true;
            }
        }
    ];

    try {
        ErrorHandler.validatePath(worktreePath, 'directory', 'registerMCPServer');
        await mcpHost.register(worktreePath);
    } catch (error) {
        await ErrorHandler.handleError(error, {
            context: 'MCPServer',
            userMessage: 'Failed to register MCP server',
            recoveryActions
        });
        throw error;
    }
}
```

### 3. Git Worktree Operations

```typescript
export async function createWorktree(branchName: string, worktreePath: string): Promise<void> {
    return ErrorHandler.wrapAsync(async () => {
        ErrorHandler.validateRequired(branchName, 'branchName', 'createWorktree');
        ErrorHandler.validateRequired(worktreePath, 'worktreePath', 'createWorktree');
        
        await gitWorktree.create(branchName, worktreePath);
    }, 'GitWorktree', 'Failed to create worktree');
}
```

## Error Logging and Monitoring

The error handling system integrates with the existing logging infrastructure:

- All errors are logged with appropriate log levels
- Error context is preserved for debugging
- Error history is maintained for analysis
- Circuit breaker state changes are logged

### Log Examples

```
[ERROR] [DockerContainer] Failed to start container: Docker is not available
[WARN]  [CircuitBreaker] Circuit breaker OPEN for resource: docker-api
[INFO]  [ErrorHandler] Attempting automatic recovery using strategy: retry
```

## Testing Error Handling

When testing components that use the error handling utilities:

### 1. Mock Error Handling
```typescript
// Mock ErrorHandler for testing
jest.mock('./util/errorHandler');
const mockedErrorHandler = ErrorHandler as jest.Mocked<typeof ErrorHandler>;

// Test error scenario
test('should handle container start failure', async () => {
    mockedErrorHandler.handleError.mockResolvedValue(undefined);
    
    await expect(containerManager.start('invalid-container')).rejects.toThrow();
    expect(mockedErrorHandler.handleError).toHaveBeenCalled();
});
```

### 2. Test Circuit Breaker
```typescript
test('should open circuit after threshold failures', async () => {
    const circuitBreaker = new CircuitBreaker('test-resource', {
        failureThreshold: 2,
        resetTimeout: 1000
    });
    
    // Simulate failures
    await expect(circuitBreaker.execute(async () => {
        throw new Error('Service unavailable');
    })).rejects.toThrow();
    
    await expect(circuitBreaker.execute(async () => {
        throw new Error('Service unavailable');
    })).rejects.toThrow();
    
    // Circuit should be open
    expect(circuitBreaker.getState()).toBe(CircuitState.OPEN);
    
    // Next call should fail immediately
    await expect(circuitBreaker.execute(async () => {
        return 'success';
    })).rejects.toThrow('Circuit breaker is OPEN');
});
```

## Conclusion

The error handling utilities provide a comprehensive framework for managing errors in the Roo Master extension. By following the patterns and best practices outlined in this document, you can ensure that your components handle errors gracefully, provide good user experience, and maintain system stability even in failure scenarios.