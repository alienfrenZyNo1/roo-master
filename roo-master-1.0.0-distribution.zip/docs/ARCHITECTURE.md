# Roo Master Project Architecture

This document outlines the high-level architecture of the Roo Master project, detailing the interactions between its core components: the VS Code Extension (Roo client), the MCP Host Server, and the Docker Tool Container.

## High-Level Architecture Diagram

```mermaid
graph TD
    A[Roo VS Code Extension (Client)] -->|Launches & Communicates via Stdio| B(MCP Host Server)
    B -->|Executes Docker Commands| C[Docker Daemon]
    C -->|Manages & Runs| D(Docker Tool Container)
    D -->|Worktree Mounted| E[/work (Inside Container)]
    B -->|`docker exec` commands| D
    F[PromptAnalyzer] -->|Analyzes Prompts| G[WorkPlanParser]
    G -->|Generates Work Plans| H[TrackExecutor]
    H -->|Manages Resources| I[GitWorktree]
    H -->|Manages Containers| J[Docker Container Manager]
    H -->|Communicates via MCP| B
    K[ErrorHandler] -->|Handles Errors| F
    K -->|Handles Errors| G
    K -->|Handles Errors| H
    L[RetryHandler] -->|Retries Failed Operations| G
    L -->|Retries Failed Operations| H
```

## Component Breakdown and Interactions

### 1. Roo VS Code Extension (Client)

The VS Code Extension serves as the primary user interface for the Roo Master project. It provides a set of commands and a tree view to manage development workflows.

**Key Components:**
- **Commands:** The extension registers various VS Code commands (e.g., `roo-master.createWorktree`, `roo-master.startToolContainers`, `roo-master.registerMcpServer`, `roo-master.showLogs`). These commands trigger the core functionalities of the extension.
- **Tree Data Provider:** The `RooMasterTreeDataProvider` manages the hierarchical view within the VS Code Explorer, displaying worktrees, running containers, and MCP server statuses.
- **Worktree Management:** Interacts with Git to create, list, and open worktrees, facilitating parallel development tracks.
- **Tool Container Management:** Provides functionality to start and stop Docker tool containers.
- **MCP Server Launcher:** Responsible for launching the MCP Host Server as a child process, typically within the context of a specific worktree. It finds an available port and sets up standard I/O communication.
- **MCP Configuration Writer:** Writes local MCP configuration files (`.roo/mcp.local.json`) to store server details like the assigned port.
- **Orchestrator Components:** A set of specialized components that manage complex development workflows:
  - **PromptAnalyzer:** (`packages/vscode-ext/src/orchestrator/promptAnalyzer.ts`) Analyzes user prompts to understand intent and determine appropriate execution strategies. Uses NLP-like analysis to identify parallelizable tracks and dependencies.
  - **WorkPlanParser:** (`packages/vscode-ext/src/orchestrator/workPlanParser.ts`) Parses and interprets work plans, breaking down complex tasks into executable steps. Creates dependency graphs and determines parallelizable track groups.
  - **TrackExecutor:** (`packages/vscode-ext/src/orchestrator/trackExecutor.ts`) Executes development tracks, managing the lifecycle of parallel development tasks. Handles resource management, error recovery, and progress reporting.
- **Utility Components:** Reusable utilities that provide common functionality across the extension:
  - **ErrorHandler:** (`packages/vscode-ext/src/util/errorHandler.ts`) Centralized error handling with structured error reporting, recovery strategies, and circuit breaker pattern implementation.
  - **RetryHandler:** (`packages/vscode-ext/src/util/retryHandler.ts`) Implements robust retry logic with exponential backoff, jitter, and circuit breaker integration for transient failures.
- **Resource Management Components:** Components that manage external resources:
  - **GitWorktree:** (`packages/vscode-ext/src/worktree/gitWorktree.ts`) Manages Git worktrees for parallel development, including branch creation and worktree lifecycle management.
  - **Docker Container Manager:** (`packages/vscode-ext/src/containers/docker.ts`) Handles Docker container lifecycle, including starting, stopping, and monitoring containers with security configurations.
  - **MCP Server Launcher:** (`packages/vscode-ext/src/mcp/launcher.ts`) Manages MCP server instances, including launching, stopping, and communication with servers.
  - **MCP Server Registration:** (`packages/vscode-ext/src/mcp/registration.ts`) Handles registration and configuration of MCP servers for different worktrees.

**Interactions:**
- **User Interface:** Provides a graphical interface for users to interact with Roo functionalities.
- **MCP Host Server:** Launches the MCP Host Server and communicates with it via standard input/output (stdio) streams. It also manages the lifecycle of the MCP Host Server process.
- **Docker Daemon:** Directly interacts with the Docker daemon to start, stop, and list tool containers.
- **File System:** Reads and writes configuration files and interacts with Git for worktree operations.
- **Orchestrator Flow:** The orchestrator components work together to manage complex development workflows:
  - User prompts are first analyzed by the `PromptAnalyzer` to extract intent, identify tracks, and determine parallelization opportunities.
  - The `WorkPlanParser` converts the analyzed prompts into structured execution plans with dependency graphs and parallel track groups.
  - The `TrackExecutor` manages the execution of these plans, handling resource allocation, parallel track execution, error recovery, and progress reporting.
- **Resource Management Flow:** The resource management components ensure proper isolation and cleanup:
  - The `GitWorktree` creates isolated working directories for each track with dedicated branches.
  - The `Docker Container Manager` starts secured containers for each track with proper security flags.
  - The `MCP Server Launcher` and `Registration` components manage server instances for each worktree.
- **Utility Services:** The error handler and retry handler provide cross-cutting concerns:
  - The `ErrorHandler` captures and processes errors from all components, providing consistent error reporting, recovery strategies, and circuit breaker protection.
  - The `RetryHandler` automatically retries failed operations with configurable backoff strategies, jitter, and circuit breaker integration.

### 2. Host MCP Server

The MCP Host Server is a local application launched by the VS Code Extension. It acts as an intermediary, exposing specific development tools to the Roo client via the Model Context Protocol (MCP).

**Key Components:**
- **`StdioMCPHost`:** Utilizes the `@modelcontextprotocol/server` library to establish a communication channel over standard I/O with the VS Code Extension.
- **Tool Registration:** Registers various tools (e.g., `build.project`, `test.run`, `lint.fix`) with defined input schemas and handlers.
- **Tool Handlers:** Each registered tool has a handler function that encapsulates the logic for executing the tool's functionality. These handlers typically involve running commands within a Docker container.
- **Error Handling:** Implements error handling that integrates with the extension's `ErrorHandler` for consistent error reporting and recovery.

**Interactions:**
- **VS Code Extension:** Communicates with the extension via stdio, receiving tool execution requests and sending back results and logs.
- **Docker Tool Container:** Executes commands within the Docker Tool Container using `docker exec`. It passes the container name and the command to be executed.
- **Worktree:** Operates within the context of a specific worktree, with the container's `/work` directory mapped to the host's worktree path.

### 3. Docker Tool Container

The Docker Tool Container is a pre-built, hardened Docker image designed to provide a consistent and isolated environment for executing development tasks.

**Key Characteristics:**
- **Base Image:** Built on a minimal base image (`node:20-slim`) to reduce the attack surface.
- **Non-Root User:** Configured to run as a non-root user with UID/GID 1000:1000, following security best practices.
- **Tooling:** Includes essential development tools like `bash`, `git`, `coreutils`, and `pnpm`.
- **Working Directory:** The default working directory inside the container is `/work`, which is designed to be a mounted volume from the host's worktree.
- **Hardening Measures:** Incorporates comprehensive security measures:
  - `--read-only`: Read-only filesystem (except for mounted volumes)
  - `--cap-drop=ALL`: Drops all Linux capabilities
  - `--security-opt=no-new-privileges`: Prevents privilege escalation
  - `--pids-limit=512`: Limits process creation
  - `--memory=4g`: Restricts memory usage
  - `--cpus=2`: Limits CPU usage
  - `--user 1000:1000`: Runs as non-root user
  - No port bindings for enhanced security

**Interactions:**
- **MCP Host Server:** Receives commands from the MCP Host Server via `docker exec`.
- **Host File System:** Accesses the host's worktree through a mounted volume at `/work`.

## Parallelization Model and Worktree Management

Roo Master leverages Git worktrees to enable parallel development. Each worktree represents a separate, isolated working copy of a repository on a different branch.

**Workflow:**
1. **Create Worktree:** The VS Code Extension allows users to create new worktrees for specific branches. This creates a new directory containing the project files.
2. **Launch MCP Server per Worktree:** An MCP Host Server instance can be launched for each active worktree. This ensures that tools executed via that MCP server operate within the context of that specific worktree.
3. **Tool Container per Worktree:** While not strictly enforced to be one-to-one, the design encourages associating tool containers with specific worktrees. The worktree's path is mounted into the container's `/work` directory.
4. **Isolated Execution:** This setup allows developers to work on multiple features or bug fixes simultaneously, each in its own isolated environment (worktree + dedicated MCP server + tool container), without interfering with other ongoing tasks.
5. **Orchestrator-Managed Workflows:** The orchestrator components enhance the parallelization model by:
   - **Prompt Analysis:** Using NLP-like analysis to identify tracks, dependencies, and parallelization opportunities from user prompts
   - **Work Plan Generation:** Creating structured execution plans with dependency graphs and complexity estimates
   - **Resource-Aware Parallel Execution:** Managing concurrent track execution based on system resources and file overlap analysis
   - **Comprehensive Error Handling:** Implementing circuit breakers, retry logic with exponential backoff, and recovery strategies
   - **Progress Reporting:** Providing real-time progress updates and status tracking through VS Code events
   - **Automatic Resource Management:** Handling lifecycle of git worktrees, Docker containers, and MCP servers for each track

## Error Handling and Recovery Architecture

The Roo Master project implements a comprehensive error handling and recovery architecture that ensures reliability and robustness:

### Error Handling Flow

1. **Error Detection:** Components detect errors during execution and report them to the `ErrorHandler`
2. **Error Classification:** Errors are classified by type, severity, and recoverability
3. **Recovery Strategy Selection:** Based on error classification, appropriate recovery strategies are selected
4. **Recovery Execution:** Recovery actions are executed, which may include retries, circuit breaker trips, or resource cleanup
5. **User Notification:** Users are informed about errors and available recovery actions through the VS Code UI

### Circuit Breaker Pattern

The project implements the circuit breaker pattern to prevent cascading failures:

- **Circuit Breaker States:** Closed (normal operation), Open (failure detection), Half-Open (recovery testing)
- **Configuration:** Configurable thresholds for failure counts, timeouts, and monitoring periods
- **Automatic Recovery:** Circuit breakers automatically attempt recovery after cooldown periods
- **Manual Reset:** Users can manually reset circuit breakers through recovery actions

### Retry Logic

The project implements sophisticated retry logic for transient failures:

- **Exponential Backoff:** Retry delays increase exponentially with each attempt
- **Jitter:** Random jitter is added to prevent thundering herd problems
- **Max Retries:** Configurable maximum number of retry attempts
- **Retryable Error Detection:** Distinguishes between retryable and non-retryable errors

## Component Interaction Patterns

### Request-Response Pattern

Most interactions between components follow a request-response pattern:

1. **Request Initiation:** A component initiates a request to another component
2. **Request Processing:** The receiving component processes the request
3. **Error Handling:** Errors are handled by the `ErrorHandler` with appropriate recovery strategies
4. **Response Generation:** A response is generated and returned to the requesting component
5. **Cleanup:** Resources are cleaned up and state is updated

### Event-Driven Pattern

The project uses event-driven patterns for progress reporting and state changes:

1. **Event Emission:** Components emit events for significant state changes
2. **Event Handling:** Other components handle these events to update their state
3. **UI Updates:** The VS Code UI is updated based on events to provide real-time feedback
4. **Logging:** Events are logged for debugging and auditing purposes

### Resource Lifecycle Management

The project implements comprehensive resource lifecycle management:

1. **Resource Allocation:** Resources (worktrees, containers, servers) are allocated for each track
2. **Resource Monitoring:** Resources are monitored for health and proper operation
3. **Resource Cleanup:** Resources are cleaned up after track completion or failure
4. **Error Recovery:** Failed resources are recovered or replaced as needed

## Worktree Management

Worktree management is handled by the VS Code extension, utilizing Git commands to create, list, and remove worktrees. This allows developers to easily switch between different branches and their corresponding isolated development environments.

### Worktree Lifecycle

1. **Creation:** Worktrees are created with dedicated branches (`puppet/<track-id>`) for each track
2. **Mounting:** Worktrees are mounted into Docker containers at the `/work` directory
3. **Operation:** Tools operate within the context of the mounted worktree
4. **Cleanup:** Worktrees are removed after track completion or when manually cleaned up

### Integration with Orchestrator

The orchestrator components manage worktree lifecycle as part of track execution:

- **Automatic Creation:** Worktrees are automatically created when tracks are executed
- **Isolation:** Each track operates in its own isolated worktree
- **Cleanup:** Worktrees are automatically cleaned up after track completion or failure
- **Error Recovery:** Failed worktrees are cleaned up and recreated during retry attempts