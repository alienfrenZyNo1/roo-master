# Orchestrator Components

This document provides comprehensive documentation for the orchestrator components in the Roo Master VS Code extension. The orchestrator is responsible for analyzing user prompts, generating work plans, and executing tracks in parallel with proper dependency management.

## Overview

The orchestrator consists of three main components:

1. **PromptAnalyzer** - Analyzes high-level user prompts and generates detailed work plans
2. **WorkPlanParser** - Parses prompts into structured work plans with tracks and dependencies
3. **TrackExecutor** - Executes tracks in parallel with proper resource management and error handling

## PromptAnalyzer

The `PromptAnalyzer` class is responsible for analyzing user prompts and generating detailed work plans with parallelizable tracks.

### Purpose

- Parse high-level user prompts into executable tracks
- Identify dependencies between tracks
- Determine optimal concurrency based on system resources
- Generate work plans with parallelizable track groups

### Key Features

- **NLP-like Analysis**: Uses keyword analysis and pattern matching to identify tasks
- **Dependency Analysis**: Automatically identifies dependencies between tracks
- **Resource Optimization**: Analyzes system resources to determine optimal concurrency
- **Parallel Execution**: Identifies tracks that can be executed in parallel

### Configuration

```typescript
const PROMPT_ANALYSIS_CONFIG = {
    // Maximum number of parallel tracks based on system resources
    maxParallelTracks: Math.min(4, Math.floor(os.cpus().length / 2)),
    // Default complexity threshold for parallel execution
    parallelComplexityThreshold: 6,
    // Keywords that indicate parallelizable tasks
    parallelKeywords: ['in parallel', 'simultaneously', 'concurrently', 'at the same time'],
    // Keywords that indicate sequential dependencies
    dependencyKeywords: ['after', 'before', 'depends on', 'once', 'then', 'followed by'],
    // File overlap threshold for determining parallelizability
    fileOverlapThreshold: 0.3, // 30% overlap is acceptable for parallel execution
};
```

### Key Methods

#### `analyzePrompt(prompt: string): Promise<WorkPlan>`

The main entry point for analyzing user prompts and generating work plans.

**Process:**
1. Parses the prompt to identify tracks using NLP-like analysis
2. Analyzes dependencies between tracks
3. Determines optimal concurrency based on system resources
4. Identifies parallelizable tracks
5. Returns a structured WorkPlan object

**Example:**
```typescript
const promptAnalyzer = new PromptAnalyzer();
const workPlan = await promptAnalyzer.analyzePrompt(
    "Implement a user authentication system and create API endpoints in parallel"
);
```

#### `parsePromptToTracks(prompt: string): Promise<Track[]>`

Parses a user prompt into a set of executable tracks.

**Features:**
- Normalizes and analyzes the prompt
- Uses WorkPlanParser for track generation
- Enhances tracks with complexity analysis
- Estimates duration and identifies file overlaps

#### `analyzeTrackDependencies(tracks: Track[], prompt: string): Graph`

Builds a dependency graph representing relationships between tracks.

**Approach:**
- Uses keyword pattern matching to identify dependencies
- Creates a directed graph using @dagrejs/graphlib
- Falls back to WorkPlanParser's dependency analysis if needed

#### `determineParallelizableTracks(tracks: Track[], dependencyGraph: Graph, systemResourceUsage): string[][]`

Determines which tracks can be executed in parallel.

**Logic:**
- Uses dependency graph to identify parallelizable groups
- Adjusts groups based on system resource constraints
- Filters groups based on file overlap analysis

### Integration with Other Components

The `PromptAnalyzer` integrates with:
- **WorkPlanParser**: For track generation and dependency analysis
- **ErrorHandler**: For error handling and recovery
- **System Resources**: For CPU and memory analysis

## WorkPlanParser

The `WorkPlanParser` class is responsible for parsing prompts into structured work plans with tracks, dependencies, and parallelization information.

### Purpose

- Convert natural language prompts into structured work plans
- Identify tracks, tasks, and dependencies
- Estimate complexity and duration
- Validate work plan integrity

### Key Features

- **Natural Language Processing**: Parses prompts using keyword analysis and pattern matching
- **Track Generation**: Creates structured tracks with tasks and metadata
- **Dependency Management**: Builds dependency graphs for execution ordering
- **Parallelization**: Determines which tracks can run in parallel
- **Validation**: Ensures work plan integrity and detects circular dependencies

### Configuration

```typescript
const PARSER_CONFIG = {
    // Keywords that indicate different types of tasks
    taskKeywords: {
        implementation: ['implement', 'create', 'build', 'develop', 'write'],
        testing: ['test', 'verify', 'validate', 'check'],
        refactoring: ['refactor', 'improve', 'optimize', 'clean up'],
        documentation: ['document', 'write docs', 'create documentation'],
        deployment: ['deploy', 'release', 'publish', 'ship'],
    },
    // Keywords that indicate dependencies
    dependencyKeywords: ['after', 'before', 'depends on', 'requires', 'once', 'then', 'followed by'],
    // Keywords that indicate parallel execution
    parallelKeywords: ['in parallel', 'simultaneously', 'concurrently', 'at the same time', 'together'],
    // File path patterns
    filePathPatterns: [
        /\.(ts|js|tsx|jsx|py|java|cpp|c|go|rs|php|rb)$/, // Source code files
        /\/src\/.*\//, // Source directories
        /\/lib\/.*\//, // Library directories
        /\/test\/.*\//, // Test directories
        /\/docs\/.*\//, // Documentation directories
    ],
    // Default complexity and duration estimates
    defaultComplexity: 5,
    defaultDuration: 60, // minutes
    complexityMultipliers: {
        simple: 0.5,
        medium: 1.0,
        complex: 1.5,
        expert: 2.0,
    },
};
```

### Key Methods

#### `parsePromptToWorkPlan(prompt: string, options?: ParseOptions): Promise<WorkPlan>`

The main method for parsing prompts into work plans.

**Process:**
1. Preprocesses and normalizes the prompt
2. Extracts tracks from the prompt
3. Analyzes dependencies between tracks
4. Determines parallelizable tracks
5. Validates the work plan

**Example:**
```typescript
const workPlanParser = new WorkPlanParser();
const workPlan = await workPlanParser.parsePromptToWorkPlan(
    "Create a user authentication system with login and registration, then build the dashboard"
);
```

#### `buildDependencyGraph(tracks: Track[]): Graph`

Constructs a Directed Acyclic Graph (DAG) from track dependencies.

**Features:**
- Uses @dagrejs/graphlib for graph operations
- Handles missing dependencies gracefully
- Provides foundation for parallelization analysis

#### `determineParallelizableTracks(tracks: Track[], dependencyGraph: Graph): string[][]`

Determines which tracks can be executed in parallel.

**Algorithm:**
1. Identifies tracks with no uncompleted dependencies
2. Sorts candidates by complexity (lower complexity first)
3. Groups tracks with minimal file overlap
4. Returns parallelizable track groups

### Data Structures

#### Track Interface

```typescript
interface Track {
    id: string;
    name: string;
    description: string;
    dependencies: string[];
    fileOverlaps: string[];
    estimatedComplexity: number;
    estimatedDuration: number;
    tasks: string[];
    status: 'pending' | 'in-progress' | 'completed' | 'blocked' | 'merged' | 'failed';
    statusMessage?: string;
}
```

#### WorkPlan Interface

```typescript
interface WorkPlan {
    id: string;
    prompt: string;
    tracks: Track[];
    dependencyGraph: Graph;
    parallelizableTracks: string[][];
}
```

### Integration with Other Components

The `WorkPlanParser` integrates with:
- **ErrorHandler**: For error handling during parsing
- **Logger**: For debugging and monitoring
- **Graph Library**: For dependency graph operations

## TrackExecutor

The `TrackExecutor` class is responsible for executing tracks in parallel with proper resource management, error handling, and progress reporting.

### Purpose

- Execute tracks from work plans in parallel
- Manage resources (git worktrees, containers, MCP servers)
- Handle errors and recovery
- Report progress to users

### Key Features

- **Parallel Execution**: Executes multiple tracks concurrently based on dependencies
- **Resource Management**: Manages git worktrees, Docker containers, and MCP servers
- **Error Handling**: Implements retry logic with exponential backoff
- **Progress Reporting**: Provides real-time progress updates
- **Circuit Breaker**: Prevents cascading failures
- **Cleanup**: Properly cleans up resources after execution

### Configuration

```typescript
const MAX_CONCURRENCY = Math.min(3, Math.floor(os.cpus().length / 2));

const RETRY_CONFIG = {
    maxRetries: 3,
    initialDelayMs: 1000,
    maxDelayMs: 30000,
    backoffFactor: 2,
};

const CONTAINER_CONFIG = {
    imageName: 'roo-master/tool-image:latest',
    containerNamePrefix: 'roo-track-',
    securityFlags: [
        '--read-only',
        '--cap-drop=ALL',
        '--security-opt=no-new-privileges',
        '--pids-limit=512',
        '--memory=4g',
        '--cpus=2',
        '--user 1000:1000',
    ],
};
```

### Key Methods

#### `executeWorkPlan(workPlan: WorkPlan): Promise<void>`

The main method for executing a work plan.

**Process:**
1. Initializes state and progress tracking
2. Processes tracks based on dependencies and parallel groups
3. Executes tracks in parallel with resource management
4. Handles failures and recovery
5. Reports completion status

**Example:**
```typescript
const trackExecutor = new TrackExecutor(context, mcpServerLauncher, mcpServerRegistration);
await trackExecutor.executeWorkPlan(workPlan);
```

#### `executeTrack(track: Track): Promise<TrackExecutionResult>`

Executes a single track with retry logic and error handling.

**Execution Steps:**
1. Creates git worktree and branch
2. Starts Docker container
3. Registers MCP server
4. Executes track tasks (build, test, lint)
5. Commits changes
6. Cleans up resources

#### `cleanupTrackResources(trackId: string): Promise<void>`

Cleans up resources associated with a track.

**Cleanup Tasks:**
- Stops MCP server
- Stops Docker container
- Removes git worktree
- Clears internal state

### Error Handling and Recovery

The `TrackExecutor` implements comprehensive error handling:

#### Retry Logic

- Implements exponential backoff
- Distinguishes between retryable and non-retryable errors
- Limits maximum retry attempts

#### Recovery Actions

- **Retry Track**: Re-executes a failed track
- **Cleanup Resources**: Cleans up all resources associated with a track
- **Reset Circuit Breaker**: Resets the circuit breaker for a track

#### Circuit Breaker Integration

- Uses circuit breakers to prevent cascading failures
- Automatically recovers from temporary failures
- Provides manual reset capabilities

### Progress Reporting

The `TrackExecutor` provides detailed progress reporting:

#### ProgressReport Interface

```typescript
interface ProgressReport {
    totalTracks: number;
    completedTracks: number;
    failedTracks: number;
    runningTracks: number;
    currentTrack?: string;
    currentProgress?: number;
}
```

#### Event System

- Emits progress updates via VS Code events
- Provides real-time feedback to users
- Integrates with VS Code UI components

### Integration with Other Components

The `TrackExecutor` integrates with:
- **GitWorktree**: For branch and worktree management
- **McpServerLauncher**: For MCP server management
- **McpServerRegistration**: For server registration
- **Docker Container**: For tool execution environment
- **ErrorHandler**: For error handling and recovery
- **CircuitBreaker**: For failure prevention

## Component Interactions

### Data Flow

1. **User Input** → PromptAnalyzer
2. **PromptAnalyzer** → WorkPlanParser (for track generation)
3. **WorkPlanParser** → WorkPlan (structured data)
4. **WorkPlan** → TrackExecutor (for execution)
5. **TrackExecutor** → Individual track execution
6. **TrackExecutor** → Progress reporting and error handling

### Error Handling Flow

1. **Error Detection** → ErrorHandler
2. **ErrorHandler** → Recovery strategies
3. **Recovery Strategies** → Retry or cleanup
4. **Circuit Breaker** → Failure prevention
5. **User Notification** → VS Code UI

### Resource Management

1. **TrackExecutor** → GitWorktree (branch creation)
2. **TrackExecutor** → Docker (container start/stop)
3. **TrackExecutor** → McpServerLauncher (server management)
4. **Cleanup** → Resource destruction and state reset

## Best Practices

### Using the Orchestrator

1. **Start with PromptAnalyzer**: Always begin with prompt analysis for optimal track generation
2. **Handle Errors Gracefully**: Implement proper error handling for all orchestrator operations
3. **Monitor Progress**: Use progress reporting to keep users informed
4. **Clean Up Resources**: Ensure proper cleanup of resources after execution
5. **Configure Appropriately**: Adjust configuration based on system capabilities

### Error Handling

1. **Use Circuit Breakers**: Protect against cascading failures
2. **Implement Retry Logic**: Handle temporary failures gracefully
3. **Log Errors**: Provide detailed logging for debugging
4. **Notify Users**: Keep users informed about errors and recovery actions
5. **Clean Up on Failure**: Always clean up resources, even when errors occur

### Performance Optimization

1. **Adjust Concurrency**: Configure concurrency based on system resources
2. **Monitor Resource Usage**: Keep track of CPU and memory usage
3. **Optimize Parallel Groups**: Group tracks efficiently for parallel execution
4. **Use File Overlap Analysis**: Prevent conflicts between parallel tracks
5. **Implement Progressive Enhancement**: Start with simple analysis and enhance as needed

## Testing and Debugging

### Testing Strategies

1. **Unit Testing**: Test individual components in isolation
2. **Integration Testing**: Test component interactions
3. **End-to-End Testing**: Test complete workflows
4. **Error Scenario Testing**: Test error handling and recovery
5. **Performance Testing**: Test with various workloads

### Debugging Tips

1. **Enable Logging**: Use detailed logging for troubleshooting
2. **Monitor Progress**: Use progress reporting to track execution
3. **Check Resource State**: Verify git worktrees, containers, and servers
4. **Analyze Dependencies**: Verify dependency graphs and parallel groups
5. **Test Error Recovery**: Verify error handling and recovery mechanisms

## Future Enhancements

### Potential Improvements

1. **AI Integration**: Enhanced NLP capabilities for better prompt analysis
2. **Dynamic Resource Allocation**: Adaptive resource management based on workload
3. **Advanced Parallelization**: More sophisticated parallel execution algorithms
4. **Enhanced Error Recovery**: Machine learning-based error prediction and recovery
5. **Performance Analytics**: Detailed performance metrics and optimization suggestions

### Extension Points

1. **Custom Track Types**: Support for specialized track types
2. **Plugin Architecture**: Plugin system for custom analysis and execution
3. **Configuration Presets**: Pre-configured settings for common scenarios
4. **Integration APIs**: APIs for integrating with external tools and services
5. **Custom Metrics**: Custom performance metrics and monitoring