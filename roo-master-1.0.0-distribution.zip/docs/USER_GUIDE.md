# Roo Master Project User Guide

This guide provides step-by-step instructions for installing, configuring, and using the Roo Master VS Code extension and its associated tools.

## 1. Installation Instructions

To get started with Roo Master, you'll need to install Docker, Git, and the Roo Master VS Code extension.

### 1.1. Prerequisites
-   **Docker:** Ensure Docker Desktop (for Windows/macOS) or Docker Engine (for Linux) is installed and running on your system. You can download it from the [official Docker website](https://www.docker.com/products/docker-desktop).
-   **Git:** Ensure Git is installed on your system. You can download it from the [official Git website](https://git-scm.com/downloads).
-   **Node.js and npm/pnpm:** Ensure Node.js (version 20 or higher recommended) and a package manager (npm or pnpm) are installed.

### 1.2. Building the Tool Container Image
The Roo Master project relies on a hardened Docker tool container image. You need to build this image locally:
1.  Open your terminal or command prompt.
2.  Navigate to the `packages/tool-image` directory within your Roo Master project:
    ```bash
    cd packages/tool-image
    ```
3.  Build the Docker image:
    ```bash
    docker build -t tool-image .
    ```
    This command tags the image as `tool-image`.

### 1.3. Installing the VS Code Extension
The Roo Master VS Code extension is typically installed from a `.vsix` file or directly from the VS Code Marketplace (if published).
1.  **From VSIX (if provided):**
    -   Open VS Code.
    -   Go to the Extensions view (`Ctrl+Shift+X` or `Cmd+Shift+X`).
    -   Click on the `...` (More Actions) menu at the top right of the Extensions sidebar.
    -   Select "Install from VSIX..." and choose the `roo-master-extension.vsix` file.
2.  **From VS Code Marketplace (if published):**
    -   Open VS Code.
    -   Go to the Extensions view (`Ctrl+Shift+X` or `Cmd+Shift+X`).
    -   Search for "Roo Master" and click "Install".

## 2. Step-by-Step Guide for Creating Worktrees

Git worktrees allow you to have multiple working copies of the same repository, each on a different branch, simultaneously. This is ideal for parallel development.

1.  Open your main Git repository in VS Code.
2.  Open the **Command Palette** (`Ctrl+Shift+P` or `Cmd+Shift+P`).
3.  Type "Roo Master" and select the command **"Roo Master: Create Worktree (new branch)"**.
4.  You will be prompted to "Enter new branch name for worktree". Enter a descriptive name for your new feature or bug fix branch (e.g., `feature/add-user-auth`).
5.  Next, you will be prompted to "Enter worktree directory name". This will be the name of the new folder where your worktree will be created (e.g., `user-auth-worktree`).
6.  A success message will appear, and the new worktree will be listed in the "Roo Master Explorer" view (usually on the left sidebar).

## 3. Instructions for Starting Tool Containers

Tool containers provide an isolated and consistent environment for running development tasks.

1.  Ensure Docker Desktop or your Docker daemon is running.
2.  Open the **Command Palette** (`Ctrl+Shift+P` or `Cmd+Shift+P`).
3.  Type "Roo Master" and select the command **"Roo Master: Start Tool Container(s)"**.
4.  You will be prompted to "Enter Docker image name". Type `tool-image` (or the name you used when building the image).
5.  You will be prompted to "Enter container name". Choose a unique name for your container (e.g., `my-dev-container-auth`).
6.  **Note:** Port bindings are no longer supported for security reasons. The container runs with `--network none` for isolation.
7.  A success message will confirm the container has started, and it will appear in the "Roo Master Explorer" view.

### Security Features Applied Automatically

When starting a tool container, the following security features are automatically applied:

-   **Read-only filesystem:** Container filesystem is mounted as read-only
-   **Dropped capabilities:** All Linux capabilities are dropped
-   **No new privileges:** Privilege escalation is prevented
-   **Resource limits:** Processes (512), memory (4GB), and CPU (2 cores) are limited
-   **Non-root user:** Container runs as user ID 1000:1000 (appuser)
-   **Network isolation:** Container runs with no network access

## 4. Guide for Registering MCP Servers with Roo

An MCP (Model Context Protocol) server is launched per worktree to enable communication between the VS Code extension and the tools running within your Docker containers.

1.  Open the worktree you wish to work on in a new VS Code window (if not already open). You can use "Roo Master: Open Worktree" for this.
2.  Open the **Command Palette** (`Ctrl+Shift+P` or `Cmd+Shift+P`).
3.  Type "Roo Master" and select the command **"Roo Master: Register MCP Server"**.
4.  If you have multiple worktrees open, you might be prompted to select the specific worktree for which to register the MCP server.
5.  A success message will indicate that the MCP server has been launched for your worktree on an available port. The "Roo Master Explorer" will show the MCP server as active with its assigned port.

## 5. Examples of Using the MCP Tools

Once an MCP server is registered and a tool container is running and mapped to your worktree, you can use the agent to execute various development tools. The following are examples of common tools provided by the MCP Host Server.

**Note:** When interacting with the agent, you will typically describe the action you want to perform, and the agent will translate that into the appropriate MCP tool call.

### 5.1. `build.project`
This tool builds your project within the tool container.

**Agent Command Example:**
"Build the project in my current worktree."
"Run a production build for the project."

**Underlying MCP Tool Call (Conceptual):**
```xml
<use_mcp_tool>
<server_name>your-mcp-server-name</server_name> <!-- The agent will infer this -->
<tool_name>build.project</tool_name>
<arguments>
{
  "install": true,
  "target": "dev"
}
</arguments>
</use_mcp_tool>
```
-   `install`: (Optional, `boolean`, default: `true`) Whether to run `npm install` or `pnpm install` before building.
-   `target`: (Optional, `string`, `dev` or `prod`, default: `dev`) The build target.

### 5.2. `test.run`
This tool runs tests for your project within the tool container.

**Agent Command Example:**
"Run all tests in the project."
"Run tests matching the pattern 'user-auth'."

**Underlying MCP Tool Call (Conceptual):**
```xml
<use_mcp_tool>
<server_name>your-mcp-server-name</server_name>
<tool_name>test.run</tool_name>
<arguments>
{
  "pattern": "src/features/user-auth/*.test.ts"
}
</arguments>
</use_mcp_tool>
```
-   `pattern`: (Optional, `string`) A glob pattern to filter which tests to run.

### 5.3. `lint.fix`
This tool runs linting and attempts to fix issues in your project within the tool container.

**Agent Command Example:**
"Run lint fix on the project."
"Fix any linting errors."

**Underlying MCP Tool Call (Conceptual):**
```xml
<use_mcp_tool>
<server_name>your-mcp-server-name</server_name>
<tool_name>lint.fix</tool_name>
<arguments>
{}
</arguments>
</use_mcp_tool>
```
-   This tool takes no specific arguments.

## 6. Troubleshooting Common Issues

### 6.1. Docker Daemon Not Running
-   **Symptom:** "Docker is not available or not installed" or similar errors when trying to start containers.
-   **Solution:** Ensure Docker Desktop (or your Docker daemon) is running. Start it manually if it's not.

### 6.2. Container Not Starting
-   **Symptom:** "Error starting container: ..." with messages about image not found or container name already in use.
-   **Solution:**
    -   Verify you have built the `tool-image` correctly (see Section 1.2).
    -   Ensure the container name you are trying to use is unique. If a container with that name already exists (even if stopped), you must remove it first (`docker rm <container-name>`) or choose a different name.
    -   Check the VS Code "Roo Master" output channel for more detailed Docker error messages.
    -   Note that port bindings are no longer supported - containers run with network isolation.

### 6.3. MCP Server Not Launching
-   **Symptom:** "Failed to register/launch MCP Server: ..."
-   **Solution:**
    -   Check the "Roo Master" output channel for errors related to `npm start` in the `mcp-host` directory.
    -   Ensure no other process is using the ports that the MCP server tries to bind to (default range 8000-9000). While Roo tries to find an open port, a persistent conflict might occur.
    -   Verify that the `mcp-host` package dependencies are installed (`cd packages/mcp-host && npm install`).

### 6.4. Build/Test/Lint Failures within Container
-   **Symptom:** MCP tool calls return `success: false` and logs indicate build/test/lint errors.
-   **Solution:**
    -   Review the logs provided by the MCP tool execution. These logs contain the output from the commands run inside the container, which will detail the specific compilation, test, or linting errors.
    -   Address the code issues in your worktree and re-run the tool.

### 6.5. Worktree Issues
-   **Symptom:** Errors when creating or opening worktrees (e.g., "branch already exists", "directory not empty").
-   **Solution:**
    -   Ensure the branch name you are trying to create does not already exist.
    -   Ensure the worktree directory name is unique and the target directory is empty.
    -   For existing worktrees, ensure they are not corrupted. You might need to manually inspect or clean up Git worktree entries if they become inconsistent.
    -   Use the provided PowerShell scripts for easier worktree management: `.\scripts\clean-demo.ps1` to clean up existing worktrees.

### 6.6. TypeScript Import Issues
-   **Symptom:** Tests fail with module import errors or "require is not defined" messages.
-   **Solution:**
    -   Ensure TypeScript files use proper ES6 import/export syntax rather than CommonJS require().
    -   Verify that functions are properly exported from source files (e.g., `export function greet() {}`).
    -   Check that test files use the correct import syntax: `import { greet } from '../src/index'`.
    -   Run `npm install` in the project directory to ensure all dependencies are installed.

### 6.7. PowerShell Script Issues
-   **Symptom:** Demo or cleanup scripts fail to execute.
-   **Solution:**
    -   Ensure you're running PowerShell, not Command Prompt or other shells.
    -   Verify execution policy allows running scripts: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`.
    -   Check that the shared PowerShell module exists at `scripts/modules/DemoUtilities.psm1`.
    -   Run scripts from the project root directory.